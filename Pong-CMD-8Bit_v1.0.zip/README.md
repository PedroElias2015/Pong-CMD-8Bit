\# 🏓 PONG CMD 8-BIT



Um jogo clássico de Pong feito em \*\*Batch (.bat) + PowerShell\*\*, rodando diretamente no Prompt de Comando do Windows com efeitos sonoros 8-bit, trilha sonora em loop, 6 níveis de dificuldade e modo para 2 jogadores!



\---



\## 📥 Como Baixar e Instalar



1\. Vá até a aba \*\*Releases\*\* (no menu à direita) e baixe o arquivo \*\*`Pong-CMD-8Bit-v1.0.zip`\*\*.

2\. \*\*⚠️ DICA IMPORTANTE:\*\* Extraia o conteúdo do arquivo `.zip` diretamente para a sua \*\*Área de Trabalho (Desktop)\*\* antes de abrir!

&#x20;  > \*Não execute o jogo de dentro do arquivo `.zip` sem extrair, senão a trilha sonora não vai tocar e a pasta de logs não será criada corretamente.\*

3\. Certifique-se de que o arquivo \*\*`Pong.bat`\*\* e a pasta \*\*`Pong\_Assets`\*\* estejam juntos no mesmo local.

4\. Dê um duplo clique em \*\*`Pong.bat`\*\* para jogar.



\---



\## 🎮 Modos de Jogo e Controles



\### 1 Jogador (Contra o Bot)

\* \*\*6 Níveis de Dificuldade:\*\* Fácil, Médio, Difícil, Muito Difícil, Insano e Impossível.

\* \*\*Mover Raquete:\*\* `W` / `S` ou `Seta para Cima` / `Seta para Baixo`.



\### 2 Jogadores (Local no mesmo teclado)

\* \*\*Jogador 1 (Esquerda - Verde):\*\* `W` (Cima) e `S` (Baixo).

\* \*\*Jogador 2 (Direita - Ciano):\*\* `Seta para Cima` e `Seta para Baixo`.



\### Comandos Gerais

\* \*\*Editar Nomes:\*\* Antes de iniciar qualquer partida, digite os nomes desejados (ou aperte `ENTER` para usar os nomes padrão).

\* \*\*Pausar:\*\* Pressione `P` durante a partida (`P` para continuar ou `M` para voltar ao menu).

\* \*\*Regra de Vitória:\*\* Vence quem fizer \*\*12 pontos\*\* primeiro.



\---



\## 💻 Requisitos

\* Windows 7, 8, 10 ou 11 (com Windows PowerShell nativo).



