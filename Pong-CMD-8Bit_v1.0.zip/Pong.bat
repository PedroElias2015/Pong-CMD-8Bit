@echo off
title PONG CMD 8-BIT
color 0A
mode con: cols=64 lines=24 >nul 2>&1
set "PONG_BAT=%~f0"
powershell -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -Command "try{$t=[IO.File]::ReadAllText($env:PONG_BAT);$m='#__PS__';iex $t.Substring($t.LastIndexOf($m)+$m.Length)}catch{Write-Host $_ -ForegroundColor Red;exit 1}"
if errorlevel 1 pause
exit /b
#__PS__
$ErrorActionPreference='Stop'
$baseDir=Split-Path -Parent $env:PONG_BAT
$logDir=Join-Path $baseDir "Logs"
if(-not (Test-Path -LiteralPath $logDir)){$null=New-Item -ItemType Directory -Path $logDir -Force}
$logFile=Join-Path $logDir ("pong_"+(Get-Date -Format "yyyyMMdd_HHmmss")+".log")
function Log($m){try{Add-Content -LiteralPath $logFile -Value ("["+(Get-Date -Format "HH:mm:ss")+"] "+$m)}catch{}}
Log "Iniciando PONG CMD 8-BIT"

function Tone($f,$d){try{if($f -ge 37 -and $d -gt 0){[Console]::Beep($f,$d)}}catch{}}
function PlayLocal($c){switch($c){'PADDLE'{Tone 650 45}'BOUNCE'{Tone 500 28}'WALL'{Tone 420 35}'BOTPOINT'{Tone 330 100;Tone 247 160}'S'{Tone 880 80;Tone 1175 140}'M'{Tone 520 25}}}
function Pos($x,$y){try{[Console]::SetCursorPosition([Math]::Max(0,$x),[Math]::Max(0,$y))}catch{}}
function ReadName($p,$def){
 [Console]::CursorVisible=$true;Write-Host $p -ForegroundColor Cyan -NoNewline
 $v=(Read-Host).Trim();[Console]::CursorVisible=$false
 if([string]::IsNullOrWhiteSpace($v)){return $def}
 if($v.Length -gt 12){$v=$v.Substring(0,12)}
 return $v.ToUpper()
}

$desk=[Environment]::GetFolderPath('Desktop');$a1=([char]193)+"rea de Trabalho";$wav=$null
foreach($d in @($desk,"$env:USERPROFILE\Desktop","$env:USERPROFILE\$a1",$baseDir)){
 $f=Join-Path $d "Pong_Assets\Pong_trilha.wav"
 if(Test-Path -LiteralPath $f){$wav=$f;Log "WAV encontrado: $wav";break}
}
if(-not $wav){Log "AVISO: Pong_trilha.wav nao encontrado"}

$Q=[System.Collections.Queue]::Synchronized((New-Object System.Collections.Queue))
$audioSrc=@'
param($Q,$wav,$logFile)
$ErrorActionPreference='SilentlyContinue'
function Log($m){try{Add-Content -LiteralPath $logFile -Value ("["+(Get-Date -Format "HH:mm:ss")+"] [AUDIO] "+$m)}catch{}}
$pl=$null
if($wav){try{$pl=New-Object System.Media.SoundPlayer;$pl.SoundLocation=$wav;$pl.Load();Log "WAV carregado"}catch{$pl=$null;Log ("ERRO WAV: "+$_.Exception.Message)}}
function Tone($f,$d){try{if($f -ge 37 -and $d -gt 0){[Console]::Beep($f,$d)}}catch{}}
while($true){
 if($Q.Count -le 0){Start-Sleep -Milliseconds 15;continue}
 switch([string]$Q.Dequeue()){
  'QUIT'{if($pl){$pl.Stop();$pl.Dispose()};return}
  '1'{if($pl){try{$pl.PlayLooping()}catch{}}}
  '0'{if($pl){$pl.Stop()}}
  'Z'{if($pl){$pl.Stop()}}
  'Y'{if($pl){$pl.Stop()}}
  'PADDLE'{Tone 650 45}'BOUNCE'{Tone 500 28}'WALL'{Tone 420 35}'BOTPOINT'{Tone 330 100;Tone 247 160}'S'{Tone 880 80;Tone 1175 140}'M'{Tone 520 25}
 }
}
'@

$rs=[runspacefactory]::CreateRunspace();$rs.Open()
$ps=[powershell]::Create();[void]$ps.AddScript($audioSrc);[void]$ps.AddArgument($Q);[void]$ps.AddArgument($wav);[void]$ps.AddArgument($logFile)
$ps.Runspace=$rs;$null=$ps.BeginInvoke();Start-Sleep -Milliseconds 200
function Cmd($c){if($ps.InvocationStateInfo.State -eq 'Running'){$Q.Enqueue($c)}else{PlayLocal $c}}

try{
 [Console]::CursorVisible=$false;[Console]::TreatControlCAsInput=$true
 while($true){
  Cmd '1'
  $opts=@("FACIL       (Bola lenta | Bot com erros)","MEDIO       (Bola normal | Verde)","DIFICIL     (Bola rapida | Amarelo escuro)","MUITO DIF.  (Bola muito rapida | Laranja)","INSANO      (Bola turbo | Vermelho claro)","IMPOSSIVEL  (Velocidade maxima | Escuro)","2 JOGADORES (P1: W/S | P2: Setas Cima/Baixo)","SAIR DO JOGO")
  $cols=@('DarkGreen','Green','DarkYellow','DarkYellow','Red','DarkRed','Cyan','Gray')
  $sel=0;Clear-Host
  while($true){
   Pos 0 0
   Write-Host "`n=================== PONG CMD 8-BIT ===================`n" -ForegroundColor Cyan
   for($i=0;$i -lt 8;$i++){
    if($i -eq $sel){Write-Host ("  > "+$opts.GetValue($i).PadRight(48)) -BackgroundColor $cols.GetValue($i) -ForegroundColor Black}
    else{Write-Host ("    "+$opts.GetValue($i).PadRight(48)) -BackgroundColor Black -ForegroundColor $cols.GetValue($i)}
   }
   Write-Host "`n  [Setas / W,S] Navegar  |  [ENTER] Selecionar`n  [P] Pausar no jogo     |  Vence quem fizer 12 pts`n======================================================" -ForegroundColor Cyan
   while(-not [Console]::KeyAvailable){Start-Sleep -Milliseconds 25}
   $k=[Console]::ReadKey($true).Key
   if($k -eq 'UpArrow' -or $k -eq 'W'){$sel=($sel+7)%8;Cmd 'M'}
   elseif($k -eq 'DownArrow' -or $k -eq 'S'){$sel=($sel+1)%8;Cmd 'M'}
   elseif($k -eq 'Enter'){Cmd '0';break}
   elseif($k -eq 'Escape'){Cmd '0';$sel=7;break}
  }
  if($sel -eq 7){Log "Usuario saiu pelo menu";break}

  $isPvP=($sel -eq 6);Clear-Host
  Write-Host "`n================ CONFIGURAR JOGADORES ================`n  (Deixe em branco e aperte ENTER para nome padrao)`n" -ForegroundColor Cyan
  if($isPvP){$p1Name=ReadName "  Jogador 1 [W / S] (Padrao: JOGADOR 1): " "JOGADOR 1";$p2Name=ReadName "  Jogador 2 [Setas] (Padrao: JOGADOR 2): " "JOGADOR 2"}
  else{$p1Name=ReadName "  Seu Nome (Padrao: VOCE): " "VOCE";$p2Name="BOT"}
  Log "Partida: Modo=$sel | $p1Name vs $p2Name"

  $cfgs=@(@(55,3,5,'FACIL','DarkGreen',32),@(40,2,3,'MEDIO','Green',92),@(28,2,2,'DIFICIL','DarkYellow',33),@(20,1,2,'MUITO DIF.','DarkYellow',93),@(13,1,1,'INSANO','Red',91),@(7,0,0,'IMPOSSIVEL','DarkRed',31),@(30,0,0,'2 JOGADORES','Cyan',36))
  $c=$cfgs.GetValue($sel);$spd=[int]$c.GetValue(0);$bd=[int]$c.GetValue(1);$be=[int]$c.GetValue(2);$bn=[string]$c.GetValue(3);$bc=[string]$c.GetValue(4);$e=[char]27;$ac="$e[$($c.GetValue(5))m"
  $W=60;$H=20;$py=8;$by=8;$bx=30;$bally=10;$vx=-1;$vy=1;$ps1=0;$bs=0;$t=0;$esc=$false;Clear-Host

  while($ps1 -lt 12 -and $bs -lt 12){
   while([Console]::KeyAvailable){
    $k=[Console]::ReadKey($true).Key
    if($isPvP){
     if($k -eq 'W' -and $py -gt 1){$py--};if($k -eq 'S' -and $py -lt ($H-4)){$py++}
     if($k -eq 'UpArrow' -and $by -gt 1){$by--};if($k -eq 'DownArrow' -and $by -lt ($H-4)){$by++}
    }else{
     if(($k -eq 'W' -or $k -eq 'UpArrow') -and $py -gt 1){$py--}
     if(($k -eq 'S' -or $k -eq 'DownArrow') -and $py -lt ($H-4)){$py++}
    }
    if($k -eq 'P'){
     Cmd 'Z';Pos 18 8
     Write-Host "+--------------------+`n                  |   JOGO PAUSADO     |`n                  | [P] Continuar      |`n                  | [M] Menu Principal |`n                  +--------------------+" -ForegroundColor Yellow
     while($true){
      if([Console]::KeyAvailable){
       $pk=[Console]::ReadKey($true).Key
       if($pk -eq 'P'){Cmd 'Y';Clear-Host;break}
       if($pk -eq 'M' -or $pk -eq 'Escape'){Cmd '0';$esc=$true;break}
      }
      Start-Sleep -Milliseconds 30
     }
    }
   }
   if($esc){Log "Partida interrompida";break}
   $t++;$bx+=$vx;if(($t%2) -eq 0){$bally+=$vy}
   if($bally -le 1){$bally=1;if($vy -ne 1){$vy=1;Cmd 'WALL'}}
   if($bally -ge ($H-1)){$bally=$H-1;if($vy -ne -1){$vy=-1;Cmd 'WALL'}}
   if($bx -eq 3 -and $bally -ge $py -and $bally -lt ($py+4)){$vx=1;Cmd 'PADDLE';if($bally -eq $py){$vy=-1}elseif($bally -eq ($py+3)){$vy=1}}
   if($bx -eq ($W-4) -and $bally -ge $by -and $bally -lt ($by+4)){$vx=-1;Cmd 'BOUNCE';if($bally -eq $by){$vy=-1}elseif($bally -eq ($by+3)){$vy=1}}
   if($bx -le 1){$bs++;if($isPvP){Cmd 'S'}else{Cmd 'BOTPOINT'};$bx=30;$bally=Get-Random -Min 3 -Max 15;$vx=1;Start-Sleep -Milliseconds 350}
   if($bx -ge ($W-2)){$ps1++;Cmd 'S';$bx=30;$bally=Get-Random -Min 3 -Max 15;$vx=-1;Start-Sleep -Milliseconds 350}
   if(-not $isPvP -and ($bd -le 0 -or ($t%$bd) -eq 0)){
    $tg=$bally-1;if($be -gt 0 -and (Get-Random -Max 10) -lt $be){$tg+=Get-Random -Min -2 -Max 3}
    if($by -lt $tg -and $by -lt ($H-4)){$by++}elseif($by -gt $tg -and $by -gt 1){$by--}
   }
   Pos 0 0
   $out="$ac"+("  $p1Name`: $ps1  |  $bn  |  $p2Name`: $bs  [P=Pausa]").PadRight($W)+"`n+"+('-'*($W-2))+"+`n"
   for($y=1;$y -lt $H;$y++){
    $l=New-Object char[] $W;for($x=0;$x -lt $W;$x++){$l.SetValue([char]' ',$x)}
    $l.SetValue([char]'|',0);$l.SetValue([char]'|',$W-1)
    if(($y%2) -eq 0){$l.SetValue([char]'.',[int]($W/2))}
    if($y -ge $py -and $y -lt ($py+4)){$l.SetValue([char]'@',2);$l.SetValue([char]'@',3)}
    if($y -ge $by -and $y -lt ($by+4)){$l.SetValue([char]'#',$W-3);$l.SetValue([char]'#',$W-2)}
    if($y -eq $bally -and $bx -gt 0 -and $bx -lt ($W-1)){$l.SetValue([char]'O',$bx)}
    $out+=((-join $l) -replace '@@',"${e}[92m##$ac" -replace '##',"${e}[96m##$ac" -replace 'O',"${e}[97mO$ac")+"`n"
   }
   Write-Host ($out+'+'+('-'*($W-2))+"+${e}[0m") -NoNewline
   Start-Sleep -Milliseconds $spd
  }
  if(-not $esc){
   Log "Fim: $p1Name $ps1 x $bs $p2Name";Cmd '1';Clear-Host
   $msg=if($isPvP){"VITORIA DE $(if($ps1 -ge 12){$p1Name}else{$p2Name}) ($ps1 x $bs)!"}else{if($ps1 -ge 12){"PARABENS $p1Name! VOCE VENCEU ($ps1 x $bs)!"}else{"FIM DE JOGO! $p2Name VENCEU ($ps1 x $bs)!"}}
   Write-Host "`n  $msg`n  Pressione qualquer tecla para voltar ao menu..." -ForegroundColor $bc
   Start-Sleep -Milliseconds 700;while([Console]::KeyAvailable){$null=[Console]::ReadKey($true)}
   $null=[Console]::ReadKey($true);Cmd '0'
  }
 }
}catch{
 $errMsg="ERRO LINHA $($_.InvocationInfo.ScriptLineNumber): $($_.Exception.Message)"
 Log $errMsg;Log ("LINHA: "+$_.InvocationInfo.Line.Trim())
 try{[Console]::CursorVisible=$true}catch{};Write-Host "`n$errMsg" -ForegroundColor Red;exit 1
}finally{
 Cmd 'QUIT';Start-Sleep -Milliseconds 50;try{$ps.Stop();$ps.Dispose();$rs.Close();$rs.Dispose()}catch{}
 try{[Console]::CursorVisible=$true;[Console]::ResetColor()}catch{};Log "Jogo finalizado"
}